package listeners;


import communication.ListenSocket;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;

/**
 *
 * @author Anthony
 */
public class JButtonReceiveListener extends Thread {

    private final ListenSocket ls;
    private final JTextArea textRec;
    private String messageReceived;
    private boolean stop ; 

    public JButtonReceiveListener(ListenSocket ls, JTextArea textRec) {
        this.ls = ls;
        this.textRec = textRec;
        this.messageReceived = "";
        stop = false ; 
    }
   
    public void setStop() { this.stop = true ; } 
    
    @Override
    public void run() {

        while(stop == false) {
        String previousMessage = messageReceived;
        Font font = new Font(Font.SERIF, Font.PLAIN, 14); 
        if (ls.getStop()) {
            stop = true ; 
            JOptionPane errorJDialog = new JOptionPane();
            errorJDialog.showMessageDialog(null, "Impossible to receive : the destination seems disconnected."
                    , "Receive : Error", JOptionPane.ERROR_MESSAGE);              
        }
        else {
        messageReceived = ls.getLastLine();
        if (!(messageReceived.equals(previousMessage) || (messageReceived.equals("")))) {
            font = new Font(Font.SERIF, Font.PLAIN, 14);
            textRec.setText("Message(s) received : " + messageReceived);
        } 
        else if (messageReceived == "null") { textRec.setText("disconnected"); stop = true ; } 
        else {
            messageReceived = previousMessage;
            font = new Font("Serif", Font.ITALIC | Font.BOLD, 12);

            BufferedReader bufderniereligne = new BufferedReader(new StringReader(messageReceived));
            String ligne = "";
            String derniereLigne = "";
            try {
                while ((derniereLigne = bufderniereligne.readLine()) != null) {
                    ligne = derniereLigne;
                }
            } catch (IOException ex) {
                JOptionPane errorJDialog = new JOptionPane();
                 errorJDialog.showMessageDialog(null, "Problème avec StreamReader. \n",
                                           "Receive : Error", JOptionPane.ERROR_MESSAGE);   
             }

            textRec.setText("You haven't received any message. \n "
                    + "Last message received : " + ligne);
        }
        textRec.setFont(font);
    }
    }
    }
}
