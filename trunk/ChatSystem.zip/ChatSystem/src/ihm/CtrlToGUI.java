package ihm;

public interface CtrlToGUI {

    public void setTextLog(String text);

    public void setAckLog(String text);

}
