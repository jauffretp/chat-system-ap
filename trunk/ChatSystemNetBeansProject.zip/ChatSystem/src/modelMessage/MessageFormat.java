package modelMessage;

public enum MessageFormat {

    JSON

}
